<aside class="lft-cont">
			<ul>
				<li><a href="blog-authors.html">Blog Authors</a></li>
				<li><a href="blog-category.html">Blog Categories</a></li>
				<li><a href="blog-view-table.html">Blogs</a></li>
				<li><a href="blog-post-view.html">Blog Posts</a></li>
				<li><a href="attach-category.html">Attach Category</a></li>
			</ul>
		</aside>