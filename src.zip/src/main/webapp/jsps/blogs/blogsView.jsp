<%@ page import ="java.sql.*"%>
<%@ page import="com.beans.Blog" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<style>
table, td, th {
  border: 1px solid Gold;
  border-collapse: collapse;
}

th{
  background-color: skyblue;
}

</style>
		<div class="main cntr">
		<div class="cntr1">
		<section class="rgt-cont centr">
			<div class="wlmsg"><h2>View Blogs</h2></div>
		
			<div class="ermsg">
				<ul>
					<c:if test = "${statusDelete ne null}">
				        <c:if test = "${statusDelete eq true}">
				            <li>Blogs with Live status can only be displayed</li>
				        </c:if>
				    </c:if>
				    
				    <c:if test = "${noBlog ne null}">
				        <c:if test = "${noBlog eq true}">
				            <li>Blogs name not found</li>
				        </c:if>
				    </c:if>
					
				</ul>
			</div>
			
			<div class="fltr">
			   <form action ="blog-view-filter.html">
			   <div class="pgn" name="pageNo">
				<a class="inact" href="" value="0">Previous</a>
	            <c:forEach var = "i" begin = "1" end = "${Total }">
                    <a href="${ paginationURL }?pageNo=${i }" value=${i }>${i }</a>
                </c:forEach>
                <a href="">Next</a>
			    </div>
				<strong>Filter by:</strong>
				<label>Blog Name</label>
				<input name = blogName type="text" >
				<strong>  Status</strong>
				<select name = status>
					<option value = live>Live</option>
					<option value = deleted>Deleted</option>
				</select>
				
				<input type="submit" value="Submit" class="sbmt" /></form>
			</div>
			
			<table >
		<tr>
		<th><b>BLOG_ID</b></th>
		<th><b>BLOG_NAME</b></th>
		<th><b>STATUS</b></th>
		<th><b>CREATED_BY</b></th>
		<th><b>CREATED_DATE</b></th>
		<th><b>UPDATED_BY</b></th>
		<th><b>UPDATED_DATE</b></th>
		</tr>
		
		<c:forEach items="${blogList}" var="blog">
		
		<tr>
		<td>${blog.blogId}</td>
		<td>${blog.blogName}</td>
		<td>${blog.status}</td>
		<td>${blog.createdBy}</td>
		<td>${blog.createdDate}</td>
		<td>${blog.updatedBy}</td>
		<td>${blog.updatedDate}</td>
		
		
		</tr>
		</c:forEach>
		</table>
			
			<div class="pgn">
				<a class="inact" href="">Previous</a>
				<a class="act" href="">1</a>
				<a href="">2</a>
				<a href="">3</a>
				<a href="">4</a>
				<a href="">Next</a>
			</div>
		</section>
		</div></div>