<aside class="rgt-cont">
			<ul>
				<li><a href="">Add Category</a></li>
				<li><a href="">Edit Category</a></li>
				<li><a href="">View Category</a></li>
			</ul>
		</aside>