package com.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.beans.BlogAuthorBean;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.driver.OracleTypes;

public class BlogAuthorDAO {

	
	
	
	/**
	 * @param bab
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public String addIntoDB(BlogAuthorBean bab) throws ClassNotFoundException, SQLException {
		DBConnection conobj = new DBConnection();
		String error="error";
		System.out.println(bab.getAuthorFirstName()+"inside add itno db");
			try(Connection con = conobj.connect()){
				CallableStatement stmt = con.prepareCall("Call HOT_ACADEMY.BLOG_POST_MODULE_PKG.ADD_AUTHORS_PRC (?,?,?,?,?,?,?,?)") ;
				stmt.setString(1, bab.getAuthorFirstName());
				stmt.setString(2, bab.getAuthorLastName());
				stmt.setString(3, bab.getAuthorQualification());
				stmt.setString(4, bab.getAuthorEmail());
				stmt.setString(5, bab.getAuthorHomeTown());
				stmt.setLong(6, bab.getAuthorPhoneNo());
				stmt.registerOutParameter(7, OracleTypes.NUMBER);
				stmt.registerOutParameter(8, OracleTypes.VARCHAR);
				stmt.execute();
				error = stmt.getString(8);
				stmt.getLong(7);
			}catch (Exception e) {
				System.out.println(e+"IN add into db time  :"+java.time.LocalDate.now());
				return error;
			}
		
		return error;
	}
	
	public String searchFromDB(BlogAuthorBean bab) throws ClassNotFoundException, SQLException {
		DBConnection conobj = new DBConnection();
		String error="error";
		System.out.println(bab.getAuthorFirstName()+"inside saerch itno db");
		try(Connection con = conobj.connect()){
			CallableStatement stmt = con.prepareCall("HOT_ACADEMY.BLOG_POST_MODULE_PKG.VIEW_AUTHORS_PRC (?,?,?,?,?,?,?,?,?)") ;
			System.out.println("after callable ");
			stmt.setString(1, "moh");
			System.out.println("firts coloumn set");
			stmt.setString(2, "m");
			System.out.println("2nd coloumn set");
			stmt.setString(3, "T");
			System.out.println("3nd coloumn set");
			stmt.setString(4, "m");
			System.out.println("4nd coloumn set");
			stmt.setInt(5, 1);
			System.out.println("5nd coloumn set");
			stmt.registerOutParameter(6, OracleTypes.CURSOR);
			System.out.println("6nd coloumn set");
			stmt.registerOutParameter(7, OracleTypes.CURSOR);
			System.out.println("7nd coloumn set");
			stmt.registerOutParameter(8, OracleTypes.NUMBER);
			System.out.println("8nd coloumn set");
			stmt.registerOutParameter(9, OracleTypes.VARCHAR);
			System.out.println("9nd coloumn set");
			stmt.execute();
			System.out.println("after result set for search");
			ResultSet rsAuthorDetails = ((OracleCallableStatement)stmt).getCursor(6);
			while(rsAuthorDetails.next())
            {
				System.out.println("First name "+ rsAuthorDetails.getInt(1)+" lname: "+rsAuthorDetails.getString(2)+"qualification : "+rsAuthorDetails.getString(3)+" email: "+rsAuthorDetails.getString(4)+" hometown: "+rsAuthorDetails.getString(5)+" action: "+rsAuthorDetails.getString(6)); 
            }
		}
		return error;
	}
	
	public ArrayList<BlogAuthorBean> getAuthorNameDetails() throws ClassNotFoundException, SQLException {
        DBConnection conobj = new DBConnection();
        ArrayList<BlogAuthorBean> al = new ArrayList<BlogAuthorBean>();
        Connection con = conobj.connect();
        System.out.println("Inside Get Author details");
        CallableStatement stmt = null;
        try {
            stmt = con.prepareCall("Call HOT_ACADEMY.BLOG_POST_MODULE_PKG.GET_AUTHOR_NMAE_DETAILS_PRC (?)");
            stmt.registerOutParameter(1, OracleTypes.CURSOR);
            stmt.execute();
            ResultSet rs = ((OracleCallableStatement) stmt).getCursor(1);
            while (rs.next()) {
                BlogAuthorBean obj=new BlogAuthorBean();
                Integer idNo=rs.getInt(1);
                obj.setAuthorId(idNo.toString());
                obj.setAuthorFullName(rs.getString(2)+" "+rs.getString(3));
                obj.setAuthorFirstName(rs.getString(2));
                obj.setAuthorLastName(rs.getString(3));
                obj.setAuthorQualification(rs.getString(4));
                obj.setAuthorEmail(rs.getString(5));
                obj.setAuthorHomeTown(rs.getString(6));
                obj.setAuthorHomeTown(rs.getString(7));
                al.add(obj);
            }
            stmt.close();
            con.close();
        } catch (SQLException se) {
            // Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            try {
                // finally block used to close resources
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }



       }



       return al;
    }
	
	public BlogAuthorBean editAuthorFromDB(int authorId) throws ClassNotFoundException, SQLException {
		DBConnection conobj = new DBConnection();
		String error="error";
		BlogAuthorBean authorBeanObj = new BlogAuthorBean();
		System.out.println(authorId+" inside edit author itno db");
			try(Connection con = conobj.connect()){
				try(CallableStatement stmt = con.prepareCall("Call\r\n" + 
						"    HOT_ACADEMY.BLOG_POST_MODULE_PKG.GET_AUTHOR_DETAILS_PRC (?,?)")){
				stmt.setLong(1, authorId);
				stmt.registerOutParameter(2, OracleTypes.CURSOR);
				stmt.execute();
				try(ResultSet rs = ((OracleCallableStatement) stmt).getCursor(2);){
					while(rs.next()) {
						authorBeanObj.setAuthorId(rs.getString(1));
						authorBeanObj.setAuthorFirstName(rs.getString(2));
						authorBeanObj.setAuthorLastName(rs.getString(3));
						authorBeanObj.setAuthorQualification(rs.getString(4));
						authorBeanObj.setAuthorEmail(rs.getString(5));
						authorBeanObj.setAuthorHomeTown(rs.getString(6));
						authorBeanObj.setAuthorPhoneNo(rs.getLong(7));
						System.out.println(rs.getString(2)+" : "+rs.getString(3)+" : "+rs.getString(4)+" : "+rs.getString(5)+" : "+rs.getString(6)+" : "+rs.getString(7)+" : ");
					}
				}
				}
			}catch (Exception e) {
				System.out.println(e+"IN add into db time  :"+java.time.LocalDate.now());
				return authorBeanObj;
			}
		
		return authorBeanObj;
	}
	
	public String updateAuthorOnDB(BlogAuthorBean bab) throws ClassNotFoundException, SQLException {
		DBConnection conobj = new DBConnection();
		String error="error";
		System.out.println(bab.getAuthorFirstName()+"inside add itno db");
			try(Connection con = conobj.connect()){
				CallableStatement stmt = con.prepareCall("Call HOT_ACADEMY.BLOG_POST_MODULE_PKG.UPDATE_AUTHORS_PRC (?,?,?,?,?,?,?,?,?)") ;
				stmt.setString(1, bab.getAuthorId());
				stmt.setString(2, bab.getAuthorFirstName());
				stmt.setString(3, bab.getAuthorLastName());
				stmt.setString(4, bab.getAuthorQualification());
				stmt.setString(5, bab.getAuthorEmail());
				stmt.setString(6, bab.getAuthorHomeTown());
				stmt.setLong(7, bab.getAuthorPhoneNo());
				stmt.registerOutParameter(8, OracleTypes.NUMBER);
				stmt.registerOutParameter(9, OracleTypes.VARCHAR);
				stmt.execute();
				error = stmt.getString(9);
				stmt.getLong(7);
			}catch (Exception e) {
				System.out.println(e+"IN add into db time  :"+java.time.LocalDate.now());
				return error;
			}
		
		return error;
	}
	
}
