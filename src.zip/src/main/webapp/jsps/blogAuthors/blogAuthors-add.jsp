<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<div class="main cntr">
	<div class="cntr1">
		<section class="rgt-cont centr">

			<div class="frm blbx">
				<form action="add-authors-into-db.html">
					<h3>Add Blogs Author</h3>
					<c:if test="${(error eq 'success')}">
						<div class="sumsg">
							<ul>
								<li>Thank you for your registration.</li>
							</ul>
						</div>
					</c:if>
					<c:if test="${(error ne 'success') && (error ne null)}">
						<div class="ermsg">
							<ul>
								<c:choose>
									<c:when test="${(error eq 'incorrect name')}">
										<li>Please enter correct name.</li>
									</c:when>
									<c:when test="${(error eq 'incorrect email id')}">
										<li>Please enter valid email id.</li>
									</c:when>

									<c:when test="${(error eq 'incorrect number')}">
										<li>Please enter correct number.</li>
									</c:when>
									<c:otherwise>
										<li>${error}</li>
									</c:otherwise>
								</c:choose>

							</ul>
						</div>
					</c:if>
					<p>
						<label for="authorFirstName">First Name</label> <input type="text"
							pattern="^[a-zA-Z]{0,30}$" name="authorFirstName"
							id="authorFirstName">
					</p>
					<p>
						<label for="authorLastName">Last Name</label> <input type="text"
							pattern="^[a-zA-Z]{0,30}$" name="authorLastName">
					</p>
					<p>
						<select name="authorQualification" id="authorQualification">
							<c:forEach var="qual" items="${qualificationList}">
								<option value="${qual}">${qual}</option>
							</c:forEach>

						</select> <label for="authorQualification">Qualification</label>

					</p>
					<p>
						<label for="authorEmail">Email</label> <input type="text"
							pattern="^[^\s@]+@[^\s@]+\.[^\s@]+$" name="authorEmail">
					</p>
					<p>
						<label for="authorHomeTown">Home Town</label> <input type="text"
							pattern="^[a-zA-Z]{0,30}$" name="authorHomeTown">
					</p>
					<p>
						<label for="authorPhoneNo">Phone Number</label> <input type="text"
							pattern="^[0-9]*$" name="authorPhoneNo">
					</p>

					<p align="right" class="cacn">
						<button type="reset" class="can">Cancel</button>
						<button type="submit" class="s-btn">Save Author</button>
					</p>
				</form>
			</div>
		</section>
	</div>
</div>

