<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<div class="frm blbx" id="update-author">
<form action="">
<h3>#2 Update Category</h3> 

<c:if test="${(error eq 'success')}">
            <div class="sumsg">
                <ul>
                    <li>Thank you for your registration.</li>
                </ul>
            </div>
</c:if>
<c:if test="${(error ne 'success') && (error ne null)}">
            <div class="ermsg">
                <ul>
                    <c:if test="${(error eq 'incorrect name')}">
                        <li>Please enter correct name.</li>
                    </c:if>
                    <c:if test="${(error eq 'incorrect email id')}">
                        <li>Please enter valid email id.</li>
                    </c:if>
                    <c:if test="${(error eq 'incorrect number')}">
                        <li>Please enter correct number.</li>
                    </c:if>
                </ul>
            </div>
        </c:if>
<label for="edit-categrory">Catergory NAme</label>
<input type="text" id="edit-categrory">
<label for="status">Status</label>
<select id="status" name="status">
<option selected="selected">--Please Select--</option>
<option>Live</option>
</select>


<p class="cacn">
<button type="reset" class="can">Cancel</button>
<button type="submit" class="s-btn">Update</button>
</p>


</form>
</div>