<section class="rgt-cont centr">
  
          <div class="frm blbx">
                <form>
                    <div class="detls">
                    <div class="ermsg">
                        <ul><li>Please Select category name.</li></ul>
                    </div>
                    <p><label>Blog category name</label> <select><option>Please select</option></select></p>
                    <p class="cacn">
                        <input type="submit" value="View" class="s-btn" />
                    </p>
                    </div>
                </form>
            </div>
            
            <div class="frm blbx">
                <form>
                
                    <h3>#1.Category posts</h3>
                    <div class="detls">
                    
                    <div class="sumsg">
                        <ul>
                            <li>Thank you for your registration.</li>
                        </ul>
                    </div>
                    
                    <div class="ermsg">
                        <ul>
                            <li>Please enter correct post id.</li>
                        </ul>
                    </div>
                    <table class="tbl vscrl">
                        <tr>
                            <th width="200"><input type="button" onclick='selects()' value="Select All"/> |
        <input type="button" onclick='deSelect()' value="Deselect All"/> </th>
                            <th width="100" align="left">Post ID</th>
                            <th width="232" align="left">Post Title</th>
                            <th width="232" align="left">Action</th>
                        </tr>
                        <tr>
                            <td align="center"><input type="checkbox" name="check" /></td>
                            <td>12345</td>
                            <td>hello eveyone</td>
                            <td><a href="">View Post</a></td>
                        </tr>
                         <tr>
                            <td align="center"><input type="checkbox" name="check" /></td>
                            <td>32415</td>
                            <td>hello guys</td>
                            <td><a href="">View Post</a></td>
                        </tr>
                    </table>
                    <p class="cacn aut"><input type="submit" value="Remove" class="s-btn" /></p>
                    </div>
                </form>
            </div>
            <div class="frm blbx">
                    <form>
                    <h3>#2. Attach post to category</h3>
                    <div class="detls">
                    <div class="ermsg">
                        <ul>
                            <li>Please select</li>                        
                        </ul>
                    </div>
                    <p><label>Post headlines</label> <select><option>Please select</option></select></p>
                    <p class="cacn">
                        <input type="reset" value="Cancel" class="can" />
                        <input type="submit" value="Attach" class="s-btn" />
                    </p>
                    <p class="cacn"><a class="lnk" href="">Add new post</a></p>
                    </div>
                    </form>
                </div>
        </section>
         <script type="text/javascript">  
            function selects(){  
                var ele=document.getElementsByName('check');  
                for(var i=0; i<ele.length; i++){  
                    if(ele[i].type=='checkbox')  
                        ele[i].checked=true;  
                }  
            }  
            function deSelect(){  
                var ele=document.getElementsByName('check');  
                for(var i=0; i<ele.length; i++){  
                    if(ele[i].type=='checkbox')  
                        ele[i].checked=false;  
                      
                }  
            }             
        </script>  