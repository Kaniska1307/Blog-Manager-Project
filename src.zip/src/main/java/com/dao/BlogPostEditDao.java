package com.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.beans.BlogPostNameBean;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.driver.OracleTypes;

public class BlogPostEditDao {

	/**
	 * @param bab
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public ArrayList<String> getEditSubmitDetails(String blogId,String postId) throws ClassNotFoundException, SQLException {
		DBConnection conobj = new DBConnection();
		ArrayList<String> al = new ArrayList<>();
		Connection con = conobj.connect();
		System.out.println("Inside blog edit dao");
		CallableStatement stmt = null;
		try {
			stmt = con.prepareCall("Call HOT_ACADEMY.BLOG_POST_MODULE_PKG.GET_POST_DETAILS_PRC (?,?,?)");
			stmt.setString(1, postId);
			stmt.setString(2, blogId);
			stmt.registerOutParameter(3, OracleTypes.CURSOR);
			stmt.execute();
			ResultSet rs = ((OracleCallableStatement) stmt).getCursor(3);
			System.out.println("before while");
			while (rs.next()) {
				System.out.println("rs");
				System.out.println("resultset");
				System.out.println("AUTHOR ID : " + rs.getString(1));
				al.add(rs.getString(1));
				System.out.println("BLOG ID : " + rs.getString(2));
				al.add(rs.getString(2));
				System.out.println("POST ID : " + rs.getString(3));
				al.add(rs.getString(3));
				System.out.println("BLOG NAME : " + rs.getString(4));
				al.add(rs.getString(4));
				System.out.println("AUTHOR NAME : " + rs.getString(5));
				al.add(rs.getString(5));
				System.out.println("POST NAME : " + rs.getString(6));
				al.add(rs.getString(6));
			}
			stmt.close();
			con.close();
		} catch (SQLException se) {
			// Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			// Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			try {
				// finally block used to close resources
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}

		}

		return al;
	}

}
