<div class="main cntr">
        <div class="cntr1">
        <section class="rgt-cont centr">
            
<div class="frm blbx">
<form action="">
<h3>Filter By : </h3> 
<label for="categoryName">Search Category</label>
<input type="text" name="categoryName" id="categoryName">
<label for="categoryIndex">Category Index</label>
<select  name="categoryIndex" id="categoryIndex">
<option value="writer" id="writer">Writer</option>
<option value="homeless" id="homeless">Homeless</option>
</select>
<p class="cacn">
<input type="submit" class="s-btn">
</p>
</form>
</div>
<table border="1">
  <tr>
    
      <th>Blog category name</th>
      <th>Status</th>
      <th>Created date</th>
      <th>Action</th>
  </tr>
  <tbody>
  
       <tr>
         <td>1</td>
         <td>2</td>
         <td>3</td>
         <td>Edit Category | View category</td>
       </tr>

  </tbody>
</table>
<div class="pgn">
                <a class="inact" href="">Previous</a>
                <a class="act" href="">1</a>
                <a href="">2</a>
                <a href="">3</a>
                <a href="">4</a>
                <a href="">Next</a>
            </div>
           
</section>
</div>
</div>
