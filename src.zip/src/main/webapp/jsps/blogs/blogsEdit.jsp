<%@ page import="java.sql.*"%>
<%@ page import="com.beans.BlogList"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<div class="main cntr">
	<div class="cntr1">
		<section class="rgt-cont centr">
			<div class="frm blbx">
				<div class="wlmsg">

					<h3>#1. Edit Blogs</h3>
				</div>
				<div class= "sumsg">
				<ul>
				<c:if test = "${result ne null}">
				<c:if test = "${result eq true}">
				<li>Record Updated</li>
				</c:if>
				</c:if>
				
				</ul>
				</div>
				<div class="ermsg">
					<ul>
						<li>Please enter correct Blog name.</li>

					</ul>
				</div>

				<h3>Edit takes</h3>
				<form action="">
					Blog name:<select name="blogId" id="blogName">
						<option value="select">please select blog</option>
						<c:forEach items="${blogList}" var="blog">
							<option value=${blog.blogId }>"${blog.blogId }- ${blog.blogName }"</option>
						</c:forEach>
					</select><br>
					<br> <input type="submit" value="Edit" onClick="edit_submit()">
				</form>
			</div>


			<div id="update_block" class="frm blbx">
				<div class="wlmsg">
					<form action="blog-update.html">
						<table class="tbl">
						  <input type="hidden" id="blogId" name="blogId" value=${ blogName }>
							<h3>#2. Update Blogs</h3>
							</div>
							<div class="ermsg">
								<ul>
									<li>Please enter correct Blog name.</li>

								</ul>
							</div>
							<tr>
							<th>Blog Id</th>
							<td><select name="blogId" id="blogName">
						<option value="select">please select blog</option>
						<c:forEach items="${blogList}" var="blog">
							<option value=${blog.blogId }>${blog.blogId }</option>
						</c:forEach>
					</select><br></td>
							<tr>
								<th>Blog name</th>
								<td><input type="text" name="blogNameOne"></td>
							</tr>
							<tr>
								<th>Status</th>
								<td><select name="status">
										<option value="live">Live</option>
										<option value="deleted">Deleted</option>
								</select></td>
							</tr>
							<tr>
								<td><input type="reset" value="Cancel"></td>
								<td><input type="submit" value="Update Blogs"></td>
							</tr>
						</table>
					</form>
				</div>
		</section>
	</div>
</div>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script>

	$(function() {
	hideUpdateBlog();
})
function edit_submit() {
	console.log("edit_submit")
	hideUpdateBlog()
	event.preventDefault();
}
function hideUpdateBlog() {
	var user_name = $("#blogName").val();
	if (user_name == "select") {
		console.log("if")
		document.getElementById("update_block").style.display = 'none'
		return false;
	} else {
		console.log("else")
		document.getElementById("update_block").style.display = 'block'
		return true;
	}
}
</script>