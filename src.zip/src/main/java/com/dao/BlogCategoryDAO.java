package com.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.beans.BlogAuthorBean;

import oracle.jdbc.driver.OracleTypes;

public class BlogCategoryDAO {

	public String addIntoDB(String categoryName) throws ClassNotFoundException, SQLException {
		DBConnection conobj = new DBConnection();
		String error="error";
		System.out.println(categoryName+"inside add itno db for category");
			try(Connection con = conobj.connect()){
				CallableStatement stmt = con.prepareCall("Call HOT_ACADEMY.BLOG_POST_MODULE_PKG.ADD_BLOG_CATEGORY_PRC (?,?,?)") ;
				stmt.setString(1,categoryName);
				stmt.registerOutParameter(2, OracleTypes.NUMBER);
				stmt.registerOutParameter(3, OracleTypes.VARCHAR);
				stmt.execute();
				error = stmt.getString(3);
				System.out.println(stmt.getLong(2));
			}catch (Exception e) {
				System.out.println(e+" category IN add into db time  :"+java.time.LocalDate.now());
				return error;
			}
		
		return error;
	}
}
