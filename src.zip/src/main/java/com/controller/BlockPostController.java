package com.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.beans.BlogAuthorNameBean;
import com.beans.BlogNameBean;
import com.beans.BlogPostBean;
import com.dao.BlogAuthorNameDropDownDao;
import com.dao.BlogNameDropDownDao;
import com.dao.BlogPostAddDao;
import com.dao.BlogPostEditDao;
import com.dao.BlogPostViewDao;
import com.google.gson.Gson;
import com.validation.BlogPostValidation;

@Controller
public class BlockPostController {
	
	BlogPostValidation check=new BlogPostValidation();

	@RequestMapping(value = "blog-post", method = RequestMethod.GET)
	public String callPost() {
		System.out.println("Hello I'm in call blogpost");
		return "blog-post";
	}

	@RequestMapping(value = "blog-post-add", method = RequestMethod.GET)
	public ModelAndView callBlogPostAdd() throws ClassNotFoundException, SQLException {
		System.out.println("Hello I'm in call blog-postadd");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("blog-post-add");
		BlogNameDropDownDao blogName = new BlogNameDropDownDao();
		BlogAuthorNameDropDownDao blogAuthorName=new BlogAuthorNameDropDownDao();
		ArrayList<BlogNameBean> blogNameDetails=blogName.getBlogDetails();
		ArrayList<BlogAuthorNameBean> blogAuthorNameDetails=blogAuthorName.getAuthorNameDetails();
		mv.addObject("blogList",blogNameDetails);
		mv.addObject("authorList", blogAuthorNameDetails);
		return mv;
	}
	
	@RequestMapping(value = "add-post-form", method = RequestMethod.GET)
	public ModelAndView callBlogPostAddSubmit(BlogPostBean postDetails) throws ClassNotFoundException, SQLException {
		System.out.println("Hello I'm in call blog-post-add-submit");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("blog-post-add");
		String error="success";
		error=check.checkDate(postDetails.getStartDate());
		error=check.checkURL(postDetails.getPostURL());
		error=check.countLength(postDetails.getPostText());
	    BlogPostAddDao obj=new  BlogPostAddDao();
	    obj.addIntoDB(postDetails);
		mv.addObject("error",error);	
		return mv;
	}

	@RequestMapping(value = "blog-post-edit", method = RequestMethod.GET)
	public ModelAndView callBlogPostEdit() throws ClassNotFoundException, SQLException {
		System.out.println("Hello I'm in call blog-postedit");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("blog-post-edit");
		BlogNameDropDownDao blogName = new BlogNameDropDownDao();
		ArrayList<BlogNameBean> blogNameDetails=blogName.getBlogDetails();
		mv.addObject("blogList",blogNameDetails);
		return mv;
	}

	@RequestMapping(value = "blog-post-view", method = RequestMethod.GET)
	public ModelAndView callBlogPostView(BlogPostBean postDetails) throws ClassNotFoundException, SQLException {
		System.out.println("Hello I'm in call blog-postview");
		String pgNo="1";
		ModelAndView mv=new ModelAndView();
		mv.setViewName("blog-post-view");
		BlogPostViewDao daoObj=new BlogPostViewDao();
		ArrayList<BlogPostBean> totalDetails=daoObj.viewDetails(postDetails,pgNo);
		mv.addObject("blogPostList",totalDetails);
		return mv;
	}
	@RequestMapping(value = "blogpost-view-filter", method = RequestMethod.GET)
	public ModelAndView callBlogPostFilterView(BlogPostBean postDetails) throws ClassNotFoundException, SQLException {
		System.out.println("Hello I'm in call blog-postview");
		String pgNo="1";
		ModelAndView mv=new ModelAndView();
		mv.setViewName("blog-post-view");
		BlogPostViewDao daoObj=new BlogPostViewDao();
		ArrayList<BlogPostBean> totalDetails=daoObj.viewDetails(postDetails,pgNo);
		mv.addObject("blogPostList",totalDetails);
		return mv;
	}
	
	@RequestMapping(value = "update-post-form", method = RequestMethod.GET)
	public ModelAndView callBlogPostUpdateSubmit(BlogPostBean postDetails) throws ClassNotFoundException, SQLException {
		System.out.println("Hello I'm in call blog-post-update-submit");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("blog-post-edit");
		String error="success";
		error=check.checkDate(postDetails.getStartDate());
		error=check.checkURL(postDetails.getPostURL());
		error=check.countLength(postDetails.getPostText());
	    BlogPostAddDao obj=new  BlogPostAddDao();
	    obj.addIntoDB(postDetails);
		mv.addObject("error",error);	
		return mv;
	}


	@ResponseBody
	@RequestMapping(value = "date-validation", method = RequestMethod.POST)
	public String dateValidationAjax(String date) {
		System.out.println("checkDate");
		BlogPostValidation val = new BlogPostValidation();
		String error = val.checkDate(date);
		return error;
	}

	@ResponseBody
	@RequestMapping(value = "url-validation", method = RequestMethod.POST)
	public String urlValidationAjax(String url) {
		System.out.println("check url");
		BlogPostValidation val = new BlogPostValidation();
		String error = val.checkURL(url);
		return error;
	}

	@ResponseBody
	@RequestMapping(value = "count-validation", method = RequestMethod.POST)
	public String countValidationAjax(String text) {
		System.out.println("count");
		BlogPostValidation val = new BlogPostValidation();
		String error
		= val.countLength(text);
		return error;
	}
	
	@ResponseBody
	@RequestMapping(value = "load-post", method = RequestMethod.GET)
	public String loadPost(String blogId) throws ClassNotFoundException, SQLException {
//		BlogPostNameDropDownDao postName=new BlogPostNameDropDownDao();
//		ArrayList<BlogPostNameBean> postNameDetails=postName.getPostDetails(blog);
 //	Map<String, String> map = new HashMap<String, String>();
		ArrayList<String> demo=new ArrayList<>();
		demo.add("Harish");
		demo.add("123");
		demo.add("145");
		Gson gson = new Gson();
		String data = gson.toJson(demo);
		return data; 
	}
	
	@ResponseBody
	@RequestMapping(value = "edit-update-autocomplete", method = RequestMethod.GET)
	public String loadUpdate(String postId,String blogId) throws ClassNotFoundException, SQLException {
		BlogPostEditDao daoObj=new BlogPostEditDao();
		ArrayList<String> updateDetails=daoObj.getEditSubmitDetails(blogId, postId);	
		Gson gson = new Gson();
		String data = gson.toJson(updateDetails);
		return data; 
	}

}
