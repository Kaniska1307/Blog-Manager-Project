package com.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.beans.BlogPostBean;

import oracle.jdbc.driver.OracleTypes;

public class BlogPostAddDao {

	/**
	 * @param bab
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public String addIntoDB(BlogPostBean bpb) throws ClassNotFoundException, SQLException {
		DBConnection conobj = new DBConnection();
		String error="Error in DB";
		String status="LIVE";
		System.out.println(bpb.getBlogId() + "inside add into db");
		try (Connection con = conobj.connect()) {
			CallableStatement stmt = con
					.prepareCall("Call  HOT_ACADEMY.BLOG_POST_MODULE_PKG.ADD_UPDATE_BLOG_POST_PRC  (?,?,?,?,?,?,?,?,?,?,?)");
			System.out.println("hii where error");
			stmt.setString(1, bpb.getPostId());
			System.out.println("Post id in dao"+bpb.getPostId());
			stmt.setString(2, bpb.getBlogId());
			System.out.println(bpb.getBlogId());
			stmt.setString(3, bpb.getAuthorId());
			System.out.println(bpb.getAuthorId());
			stmt.setString(4, bpb.getHeadlines());
			System.out.println(bpb.getHeadlines());
			stmt.setString(5, bpb.getPostText());
			System.out.println(bpb.getPostText());
			stmt.setString(6, bpb.getPostURL());
			System.out.println(bpb.getPostURL());
			stmt.setString(7, bpb.getTag());
			System.out.println(bpb.getTag());
			stmt.setString(8, bpb.getStartDate());
			System.out.println(bpb.getStartDate());
			stmt.setString(9, status);
			System.out.println(bpb.getStatus());
			stmt.registerOutParameter(10, OracleTypes.NUMBER);
			stmt.registerOutParameter(11, OracleTypes.VARCHAR);
			stmt.execute();
			error = stmt.getString(11);
			System.out.println(error);
		} catch (Exception e) {
			System.out.println(e + "IN add into db time  :" + java.time.LocalDate.now());
			return error;
		}

		return error;
	}

}
