<aside class="lft-cont rgt">
			<ul>
				<li><a href="blogCategoryAdd.html">Add Category</a></li>
				<li><a href="blogCategoryEdit.html">Edit Category</a></li>
				<li><a href="blogCategory.html">View Category</a></li>
			</ul>
		</aside>