<footer>
		<div class="main">
			
			<p class="frt-lnk">
				<a href="">View all authors</a><span>|</span>
				<a href="">View all categories</a><span>|</span>
				<a href="">View all blogs</a>
				<a href="">Attach category</a><span>|</span>
				
				<span class="copy">&copy; 2013 Hotcourses Ltd All rights reserved</span>
			</p>
			
		</div>
	</footer>