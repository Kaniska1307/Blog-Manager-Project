<aside class="lft-cont rgt">
			<ul>
				<li><a href="blog-add-page.html">Add blogs</a></li>
				<li><a href="blog-edit.html">Edit blogs</a></li>
				<li><a href="blog-view-table.html">View blogs</a></li>
			</ul>
		</aside>