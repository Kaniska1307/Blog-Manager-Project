<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<div class="main cntr">
<div class="cntr1">
<section class="rgt-cont centr">
<div class="wlmsg"><h2>Edit Blog Author</h2></div>

<div class="frm blbx" id="edit-author">


<h3>#1 Edit Author</h3>
<p>

<label for="author-name">Author Name</label>
<select name="author-name" id ="author-name">
<option value="select" selected="selected">Select</option>
<c:forEach var="author" items="${authorDetails}">
<option value="${author.getAuthorId()}">${author.getAuthorName()}</option>
</c:forEach>
</select>

</p>
<p class="cacn">
<button id="edit-author-button" value="Edit" class="s-btn">Edit</button>
</p>

</div>


<script>


$("#edit-author-button").click(function(){
    var text=$('#author-name').val();
    $.ajax({
        url: "updateauthor-db.html",
        type: 'POST',
        data: {text:text},
        success :function(result)
        {        	
        	$(result).insertAfter($("#edit-author"));
        	
        }
    });
});



</script>
</section>
</div>
</div>
