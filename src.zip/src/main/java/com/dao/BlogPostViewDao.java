package com.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.beans.BlogPostBean;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.driver.OracleTypes;

public class BlogPostViewDao {

	/**
	 * @param bab
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public 	ArrayList<BlogPostBean> viewDetails(BlogPostBean bpb,String pgNo) throws ClassNotFoundException, SQLException {
		DBConnection conobj = new DBConnection();
		ArrayList<BlogPostBean> totalDetails=new ArrayList<BlogPostBean>();
		String error="Error in DB";
		String status="LIVE";
		String index=null;
		try (Connection con = conobj.connect()) {
			CallableStatement stmt = con
					.prepareCall("Call   HOT_ACADEMY.BLOG_POST_MODULE_PKG.VIEW_BLOG_POST_PRC  (?,?,?,?,?,?,?,?,?,?)");
	        stmt.setString(1,pgNo);
			stmt.setString(2,index);
			stmt.setString(3, bpb.getBlogName());
			stmt.setString(4, bpb.getHeadlines());
			stmt.setString(5, bpb.getBlogId());
			stmt.setString(6, bpb.getPostId());
			stmt.registerOutParameter(7, OracleTypes.CURSOR);
			stmt.registerOutParameter(8, OracleTypes.CURSOR);
			stmt.registerOutParameter(9, OracleTypes.NUMBER);
			stmt.registerOutParameter(10, OracleTypes.VARCHAR);
			stmt.execute();
			ResultSet rs = ((OracleCallableStatement) stmt).getCursor(7);
			System.out.println("before while");
			while (rs.next()) {
				BlogPostBean indivDetails=new BlogPostBean();
				System.out.println("AUTHOR NAME : " + rs.getString(2));
				indivDetails.setAuthorName(rs.getString(2));
				System.out.println("BLOG NAME : " + rs.getString(4));
				indivDetails.setBlogName(rs.getString(4));
				System.out.println("HEADLINE : " + rs.getString(6));
				indivDetails.setHeadlines(rs.getString(6));
				System.out.println("POST NAME : " + rs.getString(6));
				indivDetails.setHeadlines(rs.getString(6));
				System.out.println("POST TEXT : " + rs.getString(7));
				indivDetails.setPostText(rs.getString(7));
				System.out.println("POST ID : " + rs.getString(5));
				indivDetails.setPostId(rs.getString(5));
				System.out.println("BLOG ID : " + rs.getString(3));
				indivDetails.setBlogId(rs.getString(3));
				totalDetails.add(indivDetails);
			}
			error = stmt.getString(10);
			System.out.println(error);
		} catch (Exception e) {
			System.out.println(e + "IN add into db time  :" + java.time.LocalDate.now());
			return totalDetails;
		}

		return totalDetails;
	}

}
