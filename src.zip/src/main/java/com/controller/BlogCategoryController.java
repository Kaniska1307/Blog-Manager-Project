package com.controller;

import java.sql.SQLException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.beans.BlogAuthorBean;
import com.dao.BlogAuthorDAO;
import com.dao.BlogCategoryDAO;

@Controller
public class BlogCategoryController {

	@RequestMapping(value = "blogCategorySearch",method = RequestMethod.GET)
	public ModelAndView blogCategorySearch(){
		ModelAndView mv = new ModelAndView("blogCategory");
		
		return mv;
	}
	
	@RequestMapping(value = "blogCategoryAdd",method = RequestMethod.GET)
	public ModelAndView blogCategoryAdd(){
		ModelAndView mv = new ModelAndView("blogCategoryAdd");
		
		return mv;
	}
	
	@RequestMapping(value = "blogCategoryEdit",method = RequestMethod.GET)
	public ModelAndView blogCategoryEdit(){
		ModelAndView mv = new ModelAndView("blogCategoryEdit");
		
		return mv;
	}
	
	@RequestMapping(value = "add-category-into-db",method = RequestMethod.GET)
	public ModelAndView addCategoryIntoDB(String categoryName) throws ClassNotFoundException, SQLException{
		ModelAndView mv = new ModelAndView("blogCategoryAdd");
		BlogCategoryDAO bcd = new BlogCategoryDAO();
		
		String error = bcd.addIntoDB(categoryName);
		mv.addObject("error", error);
		return mv;
	}
	
	@RequestMapping(value = "updatecategory-db",method = RequestMethod.POST)
	@ResponseBody
	public  ModelAndView editCategoryOnDB(String text) throws ClassNotFoundException, SQLException {
		System.out.println("inside editCategoryOnDB");
		System.out.println(text+" username  ");
		ModelAndView mv = new ModelAndView("blogCategoryUpdate");
		BlogAuthorDAO bad = new BlogAuthorDAO();
		BlogAuthorBean bab = new BlogAuthorBean();
		return mv;
	}
}
