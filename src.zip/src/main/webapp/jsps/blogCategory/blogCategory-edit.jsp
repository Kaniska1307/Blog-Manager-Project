<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<div class="main cntr">
        <div class="cntr1">
        <section class="rgt-cont centr">
<div class="frm blbx" id="edit-categrory">
<form action="">
<div class="wlmsg"><h3>#1 Blog Edit</h3></div>
<label for="category-name">Category Name</label> 
<select name="category-name" id="category-name">
<option value="select">Select</option>
<option value="IOT">IOT</option>
<option value="others">Others</option>
</select>
<p class="cacn">
<button id="edit-category-button" onclick="edit_submit()" class="s-btn">Edit</button>
</p>
</form>

</div>



</section>
</div>
</div>

<script>
$("#edit-category-button").click(function(){
    var text=$('#category-name').val();
    $.ajax({
        url: "updatecategory-db.html",
        type: 'POST',
        data: {text:text},
        success :function(result)
        {        	
        	$(result).insertAfter($("#edit-categrory"));
        	
        }
    });
});
</script>