<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<style>
table, td, th {
  border: 1px solid Gold;
  border-collapse: collapse;
}



th{
  background-color: skyblue;
}



</style>
<div class="main cntr">
	<div class="cntr1">
		<section class="rgt-cont centr">
			<div class="wlmsg">
				<h2>View blog Post</h2>
			</div>
			<div class="sumsg">
				<ul>
					<li>Thank you for your registration.</li>
				</ul>
			</div>
			<div class="ermsg">
				<ul>
					<li>Please enter correct Blog name.</li>

				</ul>
			</div>

			<div class="fltr">
			<form action="blogpost-view-filter.html">
				<strong>Filter by:</strong> 
				<label><strong>Blog Name</strong></label> <input type="text" name="blogName"> 
				<strong> Search Post</strong> <input type="text" name="headlines"> 
				<input type="submit" value="Submit" class="sbmt" />
			</form>
			</div>
			<div class="pgn">
				<a class="inact" href="">Previous</a> <a class="act" href="">1</a> <a
					href="">2</a> <a href="">3</a> <a href="">4</a> <a href="">Next</a>
			</div>
			<table class="tbl">
				<tr>
					<th align="left">Headline</th>
					<th align="left">Blog Name</th>
					<th align="left">User Name</th>
					<th width="10%" align="left">Action</th>
				</tr>
				<c:forEach var="blog" items="${blogPostList}">
				<tr>	
					 <td>${blog.getHeadlines()}</td>
					 <td>${blog.getBlogName()}</td>	
					 <td>${blog.getAuthorName()}</td>				
					<td class="actn"><a href="">Edit Post</a><span>|</span><a href="">View blog post</a><span>|</span><a href="">More Details</a></td>
				</tr>
				</c:forEach>
			</table>
			<div class="pgn">
				<a class="inact" href="">Previous</a> <a class="act" href="">1</a> <a
					href="">2</a> <a href="">3</a> <a href="">4</a> <a href="">Next</a>
			</div>
		</section>
	</div>
</div>