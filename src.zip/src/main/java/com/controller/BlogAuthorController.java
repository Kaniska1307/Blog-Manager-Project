package com.controller;

import java.sql.SQLException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.beans.BlogAuthorBean;
import com.dao.BlogAuthorDAO;

@Controller
public class BlogAuthorController {

	@RequestMapping(value = "blog-author-search",method = RequestMethod.GET)
	public ModelAndView blogAuthorSearch(BlogAuthorBean bab) throws ClassNotFoundException, SQLException{
		ModelAndView mv = new ModelAndView("blogAuthors");
		BlogAuthorDAO bad = new BlogAuthorDAO();
		String error = bad.searchFromDB(bab);
		return mv;
	}
	
	
	
	@RequestMapping(value = "blog-authors-add",method = RequestMethod.GET)
	public ModelAndView callAuthorAdd() {
		System.out.println("Hello I'm in call author add");
		ModelAndView mv = new ModelAndView("blogAuthorsAdd");
		BlogAuthorBean bab = new BlogAuthorBean();
		mv.addObject("qualificationList", bab.getListForQualification());
		return mv;
	}
	
	@RequestMapping(value = "blog-authors-edit",method = RequestMethod.GET)
	public ModelAndView callAuthorEdit() throws ClassNotFoundException, SQLException {
		System.out.println("Hello I'm in call author Edit");
		ModelAndView mv = new ModelAndView("blogAuthorsEdit");
		BlogAuthorBean bab = new BlogAuthorBean();
		mv.addObject("qualificationList", bab.getListForQualification());
		BlogAuthorDAO bad = new BlogAuthorDAO();
		mv.addObject("authorDetails", bad.getAuthorNameDetails());
		
		return mv;
	}
	
	@RequestMapping(value = "add-authors-into-db",method = RequestMethod.GET)
	public ModelAndView addAuthorIntoDB(BlogAuthorBean bab) throws ClassNotFoundException, SQLException {
		ModelAndView mv = new ModelAndView("blogAuthorsAdd");
		System.out.println(bab.getAuthorHomeTown()+" : AUthor home town : "+bab.getAuthorQualification());
		BlogAuthorDAO bad = new BlogAuthorDAO();
		String error = bad.addIntoDB(bab);
		mv.addObject("qualificationList", bab.getListForQualification());
		mv.addObject("error", error);
		return mv;
	}

	@RequestMapping(value = "updateauthor-db",method = RequestMethod.POST)
	@ResponseBody
	public  ModelAndView editAuthorOnDB(String text) throws ClassNotFoundException, SQLException {
		System.out.println("inside editAuthorOnDB");
		System.out.println(text+" username  ");
		ModelAndView mv = new ModelAndView("blogAuthorsUpdate");
		BlogAuthorDAO bad = new BlogAuthorDAO();
		BlogAuthorBean bab = new BlogAuthorBean();
		mv.addObject("qualificationList", bab.getListForQualification());
		mv.addObject("authorObj",bad.editAuthorFromDB(Integer.parseInt(text)));
		return mv;
	}
	
	public  ModelAndView updateAuthorIntoODB(BlogAuthorBean bab) throws ClassNotFoundException, SQLException {
		ModelAndView mv = new ModelAndView("blogAuthorsEdit");
		BlogAuthorDAO bad = new BlogAuthorDAO();
		System.out.println("blogAuthor into DB");
		String error = bad.addIntoDB(bab);
		mv.addObject("error", error);
		return mv;
	}
}
