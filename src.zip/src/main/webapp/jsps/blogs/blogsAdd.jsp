<%@ page import="java.sql.*"%>
<%@ page import="com.beans.BlogAuthors"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<div class="main cntr">
		<div class="cntr1">
		<section class="rgt-cont centr">
			<div class="wlmsg"><h2>Add Blogs</h2></div>
			<div class="sumsg">
				<ul>
				<c:if test = "${Added ne null}">
				<c:if test = "${Added eq true}">
				<li>Thank you for your registration.</li>
				</c:if>
				</c:if>
				
				</ul>
			</div>
			<div class="ermsg">
				<ul>
				<c:if test = "${Added ne null}">
				<c:if test = "${Added eq false}">
				<li>Blog name already exists</li>
				</c:if>
				</c:if>
				
				<c:if test = "${GreaterText ne null}">
				<c:if test = "${GreaterText eq true}">
				<li>Blog Name length should not be greater than 15 characters</li>
				</c:if>
				</c:if>
				</ul>
			</div>
			<form action="blog-add.html">
			Blog name:<input type ="text" name="blogName"><br><br>
			
			<button type="button" value ="Cancel" href="blogs.html">Cancel</button>
			<input type="submit" value ="Submit">
			</form>
			</section>
			</div>
			</div>
<script>
function countTextValidation() {
            var text = $("#blogName").val();
            $.post("count-validation.html",
                            {
                                text : text
                            },
                            function(data, status) {
                                if (data == "incorrect length") {
                                    $("#errorMsg").html("Please Enter BlogName less than or equal to 15 characters.");
                                    $("#errorMsg").addClass('ermsg');
                                    return true;
                                } else {
                                    $("#errorMsg").html("");
                                    $("#errorMsg").removeClass('ermsg');
                                    return false;
                                }
                            });
</script>