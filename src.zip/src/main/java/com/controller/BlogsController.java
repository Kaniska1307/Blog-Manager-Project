package com.controller;

import java.util.ArrayList;

import com.business.impl.*;
import com.beans.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.beans.Blog;
import com.dao.Blogs;
import com.validation.*;
@Controller
public class BlogsController {

	
	CommonBusinessImpl businessObj = new CommonBusinessImpl();
	
	
	@RequestMapping(value = "blog-view-table", method = RequestMethod.GET)
	public ModelAndView callAuthor(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView("blogs");
		Blogs object = new Blogs();
		BlogView viewObj = new BlogView();
		viewObj.setBlogId(null);
		viewObj.setBlogIndex(null);
		viewObj.setBlogName(null);
		viewObj.setPageNo("1");
		viewObj.setStatus(null);
		ArrayList<BlogList> blog = object.getBlogList();
		ArrayList<Blog> blogList = object.viewTable(viewObj);
		mav.addObject("Total",(blog.size())/10+1 );
		System.out.println(blog.size()+"page numbers = "+( blog.size())/10);
		mav.addObject("paginationURL", request.getRequestURI());
		mav.addObject("Submit", true);
		mav.addObject("blogList", blogList);
		return mav;
	}

	@RequestMapping(value = "blog-view-filter", method = RequestMethod.GET)
	public ModelAndView viewBlogFilter(HttpServletRequest request)throws NullPointerException {
		String blogName = request.getParameter("blogName");
		String status = request.getParameter("status");
		String pageNo = request.getParameter("pageNo");
		System.out.println("name = " + pageNo);
		ModelAndView mav = new ModelAndView("blogs");
		Blogs object = new Blogs();
		BlogView viewObj = new BlogView();
		viewObj.setBlogId(null);
		viewObj.setBlogIndex(null);
		viewObj.setBlogName(blogName);
		viewObj.setPageNo(pageNo);
		viewObj.setStatus(status);
		ArrayList<Blog> blogListFilter = object.viewTable(viewObj);
		if (status.equals("deleted")) {
			mav.addObject("statusDelete", true);
		}
		else
		{
			mav.addObject("statusDelete", false);
			if(!(blogListFilter.isEmpty()))
			{
				mav.addObject("blogList", blogListFilter);
				mav.addObject("noBlog", false);
			} 
			else
				mav.addObject("noBlog", true);
		}
		return mav;
	}

	@RequestMapping(value = "blog-add", method = RequestMethod.GET)
	public ModelAndView addBlogs(HttpServletRequest request) throws NullPointerException {
		System.out.println("Hello I'm in call add blog");
		ModelAndView mav = new ModelAndView("blogsAdd");
      
		//businessObj
		
		String blogName = request.getParameter("blogName");
		Validation validation = new Validation();
		if(validation.textValidation(blogName))
		{
			mav.addObject("GreaterText", false);
			Blogs object = new Blogs();
			String result = object.addBlog(blogName);
			if (result.equals("notAdded"))
				mav.addObject("Added", false);
			else 
				mav.addObject("Added", true);
		}
		else
		{
			mav.addObject("GreaterText", true);
		}
		
		return mav;
	}

	@RequestMapping(value = "blog-edit", method = RequestMethod.GET)
	public ModelAndView callBlogEdit(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView("blogsEdit");
		Blogs object = new Blogs();
		ArrayList<BlogList> blogList = object.getBlogList();
		mav.addObject("blogList", blogList);
		System.out.println("Hello I'm in call edit blog");
		return mav;
	}

	@RequestMapping(value = "blog-update", method = RequestMethod.GET)
	public ModelAndView callBlogUpdate(HttpServletRequest request)throws NullPointerException {
		ModelAndView mav = new ModelAndView("blogsEdit");
        String blogName = request.getParameter("blogName");
     	String status = request.getParameter("status");
		String blogId = request.getParameter("blogId");
		Validation validation = new Validation();
		if(validation.textValidation(blogName))
		{
			mav.addObject("GreaterText", false);
			BlogUpdate updateObj = new BlogUpdate();
			updateObj.setBlogId(blogId);
			updateObj.setBlogName(blogName);
			updateObj.setStatus(status);
			Blogs object = new Blogs();
			
			String result = object.updateBlog(updateObj);
			System.out.println("Hello I'm in call update view table"+ result);
			if(result=="Success")
			mav.addObject("result", true);
			else
				mav.addObject("result", false);
		}
		else
		{
			mav.addObject("GreaterText", true);
		}
		
		return mav;
	}

//	@ResponseBody
//    @RequestMapping(value = "editUpdateAutocomplete",method = RequestMethod.GET)
//    public String editUpdateAutocomplete(String user_name)
//    {
//        System.out.println("json ajx call " + user_name);
//		String JSONUsernames = action.getJSONUsernames(user_name);
//        return JSONUsernames;
//    }
}
