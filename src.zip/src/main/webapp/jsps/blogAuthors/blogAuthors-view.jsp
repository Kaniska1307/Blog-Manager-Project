<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<div class="main cntr">
        <div class="cntr1">
        <section class="rgt-cont centr">
            <div class="wlmsg"><h2>View Blogs Author</h2></div>
            
<div class="frm blbx">
<h3>Filter By</h3>
<form action="blog-author-search.html" id="blogAuthor-view">

<c:if test="${(error eq 'success')}">
            <div class="sumsg">
                <ul>
                    <li>Thank you for your registration.</li>
                </ul>
            </div>
</c:if>
<c:if test="${(error ne 'success') && (error ne null)}">
            <div class="ermsg">
                <ul>
                    <c:if test="${(error eq 'incorrect name')}">
                        <li>Please enter correct name.</li>
                    </c:if>
                    <c:if test="${(error eq 'incorrect email id')}">
                        <li>Please enter valid email id.</li>
                    </c:if>
                    <c:if test="${(error eq 'incorrect number')}">
                        <li>Please enter correct number.</li>
                    </c:if>
                </ul>
            </div>
        </c:if>


<label for="author-name">Name</label><input type="text" name="authorFirstName" id="author-name">
<label for="author-email">Email</label><input type="text" id="author-email" name="authorEmail">
<label for="authorQualification">Qualification</label>
<select name="authorQualification" id="authorQualification">
	<option value=""><---Select---></option>
<c:forEach var="qual" items="${qualificationList}">
     <option value="${qual}">${qual}</option>
</c:forEach>
</select>
<div class="cacn">
<input type="submit" class="s-btn">
</div>
</form>
</div>
<table border="1">
  <tr>
    
      <th>First Name</th>
      <th>Middle Name</th>
      <th>Qualification</th>
      <th>Email</th>
      <th>Native</th>
      <th>Action</th>
    
  </tr>
  <tbody>
  <c:forEach var="authorObj" items="${authorBean}">
       <tr>
         <td>${authorObj.etAuthorFirstName()}</td>
         <td>${authorObj.getAuthorLastName()}</td>
         <td>${authorObj.getAuthorQualification()}</td>
         <td>${authorObj.getAuthorEmail()}</td>
         <td>${authorObj.getAuthorHomeTown()}</td>
         <td><a href="">Edit author</a></td>
       </tr>
</c:forEach>
  </tbody>
</table>
<div class="pgn">
                <a class="inact" href="">Previous</a>
                <a class="act" href="">1</a>
                <a href="">2</a>
                <a href="">3</a>
                <a href="">4</a>
                <a href="">Next</a>
            </div>
</section></div></div>