package com.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.beans.BlogAuthorNameBean;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.driver.OracleTypes;

public class BlogAuthorNameDropDownDao {

	/**
	 * @param bab
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public ArrayList<BlogAuthorNameBean> getAuthorNameDetails() throws ClassNotFoundException, SQLException {
		DBConnection conobj = new DBConnection();
		ArrayList<BlogAuthorNameBean> al = new ArrayList<BlogAuthorNameBean>();
		Connection con = conobj.connect();
		System.out.println("Inside Get Author details");
		CallableStatement stmt = null;
		try {
			stmt = con.prepareCall("Call HOT_ACADEMY.BLOG_POST_MODULE_PKG.GET_AUTHOR_NMAE_DETAILS_PRC (?)");
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.execute();
			ResultSet rs = ((OracleCallableStatement) stmt).getCursor(1);
			while (rs.next()) {
				BlogAuthorNameBean obj=new BlogAuthorNameBean();
				System.out.println("AUTHOR ID : " + rs.getInt(1));
				Integer idNo=rs.getInt(1);
				obj.setAuthorId(idNo.toString());
				System.out.println("Author Fisrt NAME : " + rs.getString(2));
				System.out.println("Author Last NAME : " + rs.getString(3));
				String firstName=rs.getString(2);
				String lastName=rs.getString(3);
				obj.setAuthorName(firstName+" "+lastName);
				al.add(obj);
			}
			stmt.close();
			con.close();
		} catch (SQLException se) {
			// Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			// Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			try {
				// finally block used to close resources
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}

		}

		return al;
	}

}
