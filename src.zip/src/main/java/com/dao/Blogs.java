package com.dao;
import java.sql.*;
import java.util.ArrayList;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;



import com.beans.*;
import com.dao.DBConnection;

/**
* This class is used to show the login page content
*
* @author Abinaya R
* @since 28-10-2022 - initial draft
* @version 1.1
*/
public class Blogs {
	
	public String addBlog(String blogName)
	{
		Blogs object = new Blogs();
		BlogView viewObj = new BlogView();
		viewObj.setBlogId(null);
		viewObj.setBlogIndex(null);
		viewObj.setBlogName(null);
		viewObj.setPageNo("1");
		viewObj.setStatus(null);
		ArrayList<Blog> blogList = object.viewTable(viewObj);
		String error=null;
		if(!(blogList.isEmpty()))
		{
			for (int i = 0; i < blogList.size(); i++)
			 {
				 Blog blogObj = blogList.get(i);
				 System.out.println(blogName+" name = "+blogObj.getBlogName());
				 if((blogObj.getBlogName()).equalsIgnoreCase(blogName))
				 {
					 System.out.println("blog matched");
					 return "notAdded";
				 }	
			 }
		}
		DBConnection DBobject = new DBConnection();
		Connection connection= null;
		CallableStatement stmt = null;
		System.out.println("statement executed initial");
		try
		{
			connection = DBobject.connect();
			stmt = connection.prepareCall("Call HOT_ACADEMY.BLOG_POST_MODULE_PKG.ADD_BLOGS_PRC(?, ?, ?)");
			stmt.setString(1, blogName);
			System.out.println("blog setted");
			stmt.registerOutParameter(2,  OracleTypes.NUMBER);
			stmt.registerOutParameter(3,  OracleTypes.VARCHAR);
			System.out.println("statement executed before");
			stmt.execute();
			System.out.println("statement executed");
			int errorCode = ((OracleCallableStatement)stmt).getInt(2);
			
			error = ((OracleCallableStatement)stmt).getString(3);
			System.out.println("error = "+errorCode +"   "+error);
			stmt.close();
			 connection.close();
		}
		catch (SQLException e)
		{
			System.out.println(" sql error"+ e.getMessage());
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("update done wrong "+  e.getMessage());
		}
		return error;
	}

	public ArrayList<BlogList> getBlogList()
	{
		DBConnection object = new DBConnection();
		Connection connection= null;
		ArrayList<BlogList> blogList= new ArrayList<BlogList>();
		CallableStatement stmt = null;
		System.out.println("statement executed initial");
		try
		{
			connection = object.connect();
			stmt = connection.prepareCall("Call HOT_ACADEMY.BLOG_POST_MODULE_PKG.GET_BLOG_LIST_PRC(?)");
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.execute();
	        ResultSet rs = ((OracleCallableStatement)stmt).getCursor(1);
	        System.out.println("statement executed "+ rs);
	        
	        while (rs.next()) {
	        	BlogList blogObj = new BlogList();
	        	System.out.println("statement executed 1");
                System.out.println("BLOG ID : " + rs.getInt(1));
                System.out.println("BLOG NAME : " + rs.getString(2));
                blogObj.setBlogId(rs.getInt(1));
                blogObj.setBlogName(rs.getString(2));
                blogList.add(blogObj);
            }
	        
	        stmt.close();
			 connection.close();
		}
		catch (SQLException e)
		{
			System.out.println(" sql error"+ e.getMessage());
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("update done wrong "+  e.getMessage());
		}
		return blogList;
	}
	
	public ArrayList<BlogAuthors> getAuthorList()
	{
		DBConnection object = new DBConnection();
		Connection connection= null;
		ArrayList<BlogAuthors> authorList= new ArrayList<BlogAuthors>();
		CallableStatement stmt = null;
		System.out.println("statement executed initial");
		try
		{
			connection = object.connect();
			stmt = connection.prepareCall("Call HOT_ACADEMY.BLOG_POST_MODULE_PKG.GET_AUTHOR_NMAE_DETAILS_PRC (?)");
            stmt.registerOutParameter(1, OracleTypes.CURSOR);
            stmt.execute();
            
	        ResultSet rs = ((OracleCallableStatement)stmt).getCursor(1);
	        System.out.println("statement executed "+ rs);
	        
	        System.out.println("statement executed  done ");
	        while (rs.next()) {
	        	BlogAuthors author = new BlogAuthors();
	        	System.out.println("statement executed 1");
                System.out.println("AUTHOR ID : " + rs.getInt(1));
                System.out.println("AUTHOR NAME : " + rs.getString(2));
                author.setAuthorId( rs.getInt(1)+"");
                author.setAuthorName(rs.getString(2));
                authorList.add(author);
            }
	        System.out.println("statement executed  done 2");
	        stmt.close();
			 connection.close();
		}
		catch (SQLException e)
		{
			System.out.println(" sql error");
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("update done wrong "+  e.getMessage());
		}
		return authorList;
	}
	public ArrayList<Blog> viewTable(BlogView viewObj)
	{
		DBConnection object = new DBConnection();
		Connection connection= null;
		ArrayList<Blog> blogList= new ArrayList<Blog>(5);
		CallableStatement stmt = null;
		System.out.println("statement executed initial");
		try
		{
			connection = object.connect();
			
			stmt = connection.prepareCall("Call HOT_ACADEMY.BLOG_POST_MODULE_PKG.VIEW_BLOGS_PRC(?,?,?,?,?,?,?,?,?)");
			System.out.println("connection done");
			System.out.println("page "+viewObj.getPageNo());
			stmt.setString(1, viewObj.getPageNo());
			stmt.setString(2, viewObj.getBlogIndex());
			stmt.setString(3, viewObj.getBlogName());
			stmt.setString(4, viewObj.getStatus());
			stmt.setString(5, viewObj.getBlogId());
			stmt.registerOutParameter(6, OracleTypes.CURSOR);
			stmt.registerOutParameter(7, OracleTypes.CURSOR);
			stmt.registerOutParameter(8, OracleTypes.NUMBER);
			stmt.registerOutParameter(9, OracleTypes.VARCHAR);
           
	        try {
	        	 stmt.execute();
	             
	 	         ResultSet rs = ((OracleCallableStatement)stmt).getCursor(7);
	 	         System.out.println("Result set  = "+ rs);
					while(rs.next())
					{
						Blog blogObj = new Blog();
						blogObj.setBlogId(Integer.parseInt(rs.getString(1)));
						blogObj.setBlogName(rs.getString("BLOG_NAME"));
						System.out.println(rs.getInt("BLOG_ID") +" blog detail  "+ rs.getString("BLOG_NAME"));
						blogObj.setStatus(rs.getString("STATUS"));
						blogObj.setCreatedBy(rs.getString("CREATED_BY"));
						blogObj.setCreatedDate(rs.getString("CREATED_DATE"));
						blogObj.setUpdatedBy(rs.getString("UPDATED_BY"));
						blogObj.setUpdatedDate(rs.getString("UPDATED_DATE"));
						blogList.add(blogObj);
					}
					System.out.println("list = "+ blogList);
					return blogList;
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			
		}
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("update done wrong "+  e.getMessage());
		}
		finally
		{
			try
			{
				
				if(connection!=null);
					connection.close();
			}
			catch(Exception e){}
			
		}
		return blogList;
	}
	
	public String updateBlog(BlogUpdate updateObj)
	{
		DBConnection object = new DBConnection();
		Connection connection= null;
		String error=null;
		CallableStatement stmt = null;
		System.out.println("statement executed initial");
		try
		{
			connection = object.connect();
			
			stmt = connection.prepareCall("Call HOT_ACADEMY.BLOG_POST_MODULE_PKG.UPDATE_BLOGS_PRC(?,?,?,?,?)");
			System.out.println("connection done");
			stmt.setString(1, updateObj.getBlogName());
			//stmt.setLong(2, Long.parseLong(updateObj.getBlogId()));
			stmt.setString(2, updateObj.getBlogId());
			stmt.setString(3, updateObj.getStatus());
			stmt.registerOutParameter(4,  OracleTypes.NUMBER);
			stmt.registerOutParameter(5,  OracleTypes.VARCHAR);
			System.out.println("statement executed before");
			stmt.execute();
			System.out.println("statement executed");
			int errorCode = ((OracleCallableStatement)stmt).getInt(4);
			
			error = ((OracleCallableStatement)stmt).getString(5);
			System.out.println("error = "+errorCode +"   "+error);
			stmt.close();
			 connection.close();
			 if(errorCode==0)
					return "Success";
		}
		catch (SQLException e)
		{
			System.out.println(" sql error"+ e.getMessage());
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("update done wrong "+  e.getMessage());
		}
		return error;
	}
}
