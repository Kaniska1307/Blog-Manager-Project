
<div class="main cntr">
        <div class="cntr1">
        <section class="rgt-cont centr">
            
<div class="frm blbx">
<h3>Add Blogs Category</h3>
<form action="add-category-into-db.html">
<table >
<tr>
<th>Blog category name </th>
<td><input type="text" name="categoryName"> </td>
</tr>
</table>
<Div align="right">
<p align="right" class="cacn">
<button type="reset" class="can">Cancel</button>
<button type="submit" class="s-btn">Save Category</button>
</p>
</Div>
</form>
</div>
</section>
</div>
</div>