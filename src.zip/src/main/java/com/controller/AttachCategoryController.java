package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AttachCategoryController {
  
	@RequestMapping(value = "attach-category",method = RequestMethod.GET)
	public String callAttachCategory()
	{
		return "attach-category";
	}
}
