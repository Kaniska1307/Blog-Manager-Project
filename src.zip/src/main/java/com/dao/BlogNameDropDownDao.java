package com.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.beans.BlogNameBean;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.driver.OracleTypes;

public class BlogNameDropDownDao {

	/**
	 * @param bab
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public ArrayList<BlogNameBean> getBlogDetails() throws ClassNotFoundException, SQLException {
		DBConnection conobj = new DBConnection();
		ArrayList<BlogNameBean> al = new ArrayList<BlogNameBean>();
		Connection con = conobj.connect();
		System.out.println("InsideGetblog details");
		CallableStatement stmt = null;
		try {
			stmt = con.prepareCall("Call HOT_ACADEMY.BLOG_POST_MODULE_PKG.GET_BLOG_LIST_PRC (?)");
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.execute();
			ResultSet rs = ((OracleCallableStatement) stmt).getCursor(1);
			System.out.println("above while");
			while (rs.next()) {
				System.out.println("resultset");
				BlogNameBean obj=new BlogNameBean();
				System.out.println("BLOG ID : " + rs.getString(1));
				obj.setBlogid(rs.getString(1));
				
				System.out.println("BLOG NAME : " + rs.getString(2));
				obj.setBlogName(rs.getString(2));
				al.add(obj);
			}
			stmt.close();
			con.close();
		} catch (SQLException se) {
			// Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			// Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			try {
				// finally block used to close resources
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}

		}

		return al;
	}

}
